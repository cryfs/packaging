
#ifndef CRYFS_EXPORT_H
#define CRYFS_EXPORT_H

#ifdef CRYFS_STATIC_DEFINE
#  define CRYFS_EXPORT
#  define CRYFS_NO_EXPORT
#else
#  ifndef CRYFS_EXPORT
#    ifdef cryfs_EXPORTS
        /* We are building this library */
#      define CRYFS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CRYFS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CRYFS_NO_EXPORT
#    define CRYFS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CRYFS_DEPRECATED
#  define CRYFS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CRYFS_DEPRECATED_EXPORT
#  define CRYFS_DEPRECATED_EXPORT CRYFS_EXPORT CRYFS_DEPRECATED
#endif

#ifndef CRYFS_DEPRECATED_NO_EXPORT
#  define CRYFS_DEPRECATED_NO_EXPORT CRYFS_NO_EXPORT CRYFS_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define CRYFS_NO_DEPRECATED
#endif

#endif
